function r(){let e=document.getElementById("files_page_load_config");if(e===null)return;let t=e.dataset;history.replaceState({currentDirectory:t.currentDirectory,currentDirectoryUrl:t.currentDirectoryUrl,currentDirectoryUpdatedAt:t.currentDirectoryUpdatedAt,currentFilesPath:t.currentFilesPath,currentFilesUploadPath:t.currentFilesUploadPath,currentFilesystem:t.currentFilesystem},null)}export{r as setPageLoadState};
//# sourceMappingURL=/pun/sys/dashboard/assets/files/page_load.js-5ea45a0fc5f8d6f3f03d1d1b90fc309289138b156e3570ee77eb0b2b979329e3.map
//!
;
