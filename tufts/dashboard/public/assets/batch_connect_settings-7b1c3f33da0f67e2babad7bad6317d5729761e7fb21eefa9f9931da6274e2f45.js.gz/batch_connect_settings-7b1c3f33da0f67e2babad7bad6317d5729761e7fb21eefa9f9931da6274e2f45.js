function e(){$("body").addClass("modal-open"),$("#full-page-spinner").removeClass("d-none")}function n(){$(".full-page-spinner").each((a,r)=>{let t=$(r);t.is("a")?t.on("click",e):t.closest("form").on("submit",e)})}jQuery(function(){n()});
//# sourceMappingURL=/pun/sys/dashboard/assets/batch_connect_settings.js-741c26a3bf7744c8123fc3f14e8a4143f5a841e5a9ac5bfb3a2363a5e692a15c.map
//!
;
