var e="ood_config";function n(){return document.getElementById(e).dataset}function a(){let t=n();return parseInt(t.appsDatatablePageLength)}jQuery(function(){let t=a();$("#all-apps-table").DataTable({stateSave:!1,pageLength:t})});
//# sourceMappingURL=/pun/sys/dashboard/assets/apps.js-9b6e9ad4152692a2bc9f1671f00afeb6ecc425bcb7deb19b7d692a309b64b798.map
//!
;
